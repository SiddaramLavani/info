#!/usr/bin/env bash
# Test 2: measure cyclictest wake-up latency on the UFS IRQ CPU while fio writes on other CPUs,
# and capture scheduler/IRQ/workqueue/block trace events.
# Usage:
#   sudo TEST_DIR=/mnt/f2fs_ufs4g LABEL=patched FOLIO_N=64 ./test2_ufs_sched_trace.sh
#
# Requires fio and cyclictest (usually provided by rt-tests).
# Does NOT format/discard the UFS device; only creates/removes its own test directory.

set -Eeuo pipefail

TR=${TR:-/sys/kernel/tracing}
TEST_DIR=${TEST_DIR:-/mnt/f2fs_ufs4g}
LABEL=${LABEL:-run}
FOLIO_N=${FOLIO_N:-unknown}
ENTRY_N=${ENTRY_N:-unknown}
IRQ_CPU=${IRQ_CPU:-}
DURATION=${DURATION:-30}
INTERVAL_US=${INTERVAL_US:-200}
RT_PRIO=${RT_PRIO:-80}
OUT_ROOT=${OUT_ROOT:-"$PWD/trace_results"}
STAMP=$(date +%Y%m%d_%H%M%S)
OUT="$OUT_ROOT/${LABEL}_N${FOLIO_N}_sched_$(uname -r)_$STAMP"
WORK=""
ENABLED="$OUT/enabled_events.txt"
FIO_PID=""
CYCLIC_PID=""

log() { echo "[$(date +%H:%M:%S)] $*"; }
die() { echo "ERROR: $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v fio >/dev/null || die "fio is required."
command -v cyclictest >/dev/null || die "cyclictest is required (rt-tests package)."
[[ -d "$TEST_DIR" ]] || die "TEST_DIR does not exist: $TEST_DIR"
[[ "$(findmnt -n -o FSTYPE -T "$TEST_DIR" 2>/dev/null)" == "f2fs" ]] ||
    die "$TEST_DIR must be on a mounted F2FS filesystem."
[[ -d "$TR/events" && -w "$TR/tracing_on" ]] || die "tracefs unavailable/writable at $TR"
[[ "$(cat "$TR/tracing_on")" == "0" ]] || die "Tracing is already active. Stop the other tracing session first."

detect_irq_cpu() {
    local irq affinity
    irq=$(awk '/ufshcd|ufs/{gsub(":", "", $1); print $1; exit}' /proc/interrupts)
    [[ -n "$irq" ]] || return 1
    affinity="/proc/irq/$irq/smp_affinity_list"
    [[ -r "$affinity" ]] || return 1
    sed 's/,.*//; s/-.*//' "$affinity"
}
if [[ -z "$IRQ_CPU" ]]; then
    IRQ_CPU=$(detect_irq_cpu) || die "Cannot detect UFS IRQ CPU. Set IRQ_CPU manually after checking /proc/interrupts and /proc/irq/*/smp_affinity_list."
fi

ONLINE=$(getconf _NPROCESSORS_ONLN)
OTHERS=""
for ((c=0; c<ONLINE; c++)); do
    [[ "$c" == "$IRQ_CPU" ]] || OTHERS="${OTHERS:+$OTHERS,}$c"
done
[[ -n "$OTHERS" ]] || die "Need at least two online CPUs."
mkdir -p "$OUT_ROOT" "$OUT"
WORK=$(mktemp -d "$TEST_DIR/f2fs_trace_test2.XXXXXX")
: > "$ENABLED"

cleanup() {
    [[ -n "$FIO_PID" ]] && kill "$FIO_PID" 2>/dev/null || true
    [[ -n "$CYCLIC_PID" ]] && kill "$CYCLIC_PID" 2>/dev/null || true
    wait "$FIO_PID" 2>/dev/null || true
    wait "$CYCLIC_PID" 2>/dev/null || true
    echo 0 > "$TR/tracing_on" 2>/dev/null || true
    while IFS= read -r ev; do
        [[ -n "$ev" ]] && echo 0 > "$TR/events/${ev/:/\/}/enable" 2>/dev/null || true
    done < "$ENABLED"
    [[ -n "$WORK" && -d "$WORK" ]] && rm -rf "$WORK"
}
trap cleanup EXIT INT TERM

EVENTS=(
  sched:sched_wakeup
  sched:sched_switch
  irq:irq_handler_entry
  irq:irq_handler_exit
  workqueue:workqueue_queue_work
  workqueue:workqueue_execute_start
  workqueue:workqueue_execute_end
  block:block_rq_issue
  block:block_rq_complete
)
: > "$OUT/event_formats.txt"
for ev in "${EVENTS[@]}"; do
    group=${ev%%:*}; name=${ev#*:}
    file="$TR/events/$group/$name/enable"
    if [[ -e "$file" ]]; then
        echo 1 > "$file"
        echo "$ev" >> "$ENABLED"
        [[ -r "$TR/events/$group/$name/format" ]] && {
            echo "===== $ev =====" >> "$OUT/event_formats.txt"
            cat "$TR/events/$group/$name/format" >> "$OUT/event_formats.txt"
        }
    else
        log "SKIP unavailable event: $ev"
    fi
done

grep -q '^sched:sched_wakeup$' "$ENABLED" ||
    die "sched:sched_wakeup event unavailable."
grep -q '^sched:sched_switch$' "$ENABLED" ||
    die "sched:sched_switch event unavailable."

echo 8192 > "$TR/buffer_size_kb" 2>/dev/null || true
: > "$TR/trace"
echo 1 > "$TR/tracing_on"

log "UFS IRQ CPU=$IRQ_CPU; fio CPUs=$OTHERS"
log "Starting cyclictest: duration=${DURATION}s interval=${INTERVAL_US}us priority=$RT_PRIO"
cyclictest -p "$RT_PRIO" -t 1 -a "$IRQ_CPU" -i "$INTERVAL_US" -D "${DURATION}s" \
    > "$OUT/cyclictest.txt" 2>&1 &
CYCLIC_PID=$!

sleep 1
log "Starting fio buffered write load on CPUs $OTHERS"
fio --name=f2fs_sched_load \
    --directory="$WORK" \
    --filename_format='fiofile.$jobnum' \
    --rw=write --bs=1M --size=256M --numjobs=4 \
    --time_based --runtime="$DURATION" \
    --ioengine=psync --direct=0 --end_fsync=1 \
    --cpus_allowed="$OTHERS" --cpus_allowed_policy=shared \
    --group_reporting --output-format=json --output="$OUT/fio.json" \
    > "$OUT/fio.stdout" 2> "$OUT/fio.stderr" &
FIO_PID=$!

wait "$FIO_PID"; FIO_RC=$?; FIO_PID=""
wait "$CYCLIC_PID"; CYCLIC_RC=$?; CYCLIC_PID=""
sleep 1
echo 0 > "$TR/tracing_on"
cat "$TR/trace" > "$OUT/trace.log"

{
    echo "label=$LABEL"
    echo "kernel=$(uname -r)"
    echo "folio_limit=$FOLIO_N"
    echo "entry_limit=$ENTRY_N"
    echo "ufs_irq_cpu=$IRQ_CPU"
    echo "fio_cpus=$OTHERS"
    echo "duration_seconds=$DURATION"
    echo "interval_us=$INTERVAL_US"
    echo "fio_rc=$FIO_RC"
    echo "cyclictest_rc=$CYCLIC_RC"
    echo
    echo "cyclictest_summary:"
    grep -E 'Min:|T:|Max:' "$OUT/cyclictest.txt" | tail -5 || cat "$OUT/cyclictest.txt"
    echo
    echo "trace_event_counts:"
    for ev in "${EVENTS[@]}"; do
        group=${ev%%:*}; name=${ev#*:}
        printf '%s=%s\n' "$ev" "$(grep -c "${name}:" "$OUT/trace.log" || true)"
    done
    echo "f2fs_completion_work_queued=$(grep -E 'workqueue_queue_work:.*f2fs_write_end_io_work' "$OUT/trace.log" | wc -l)"
    echo "f2fs_completion_work_started=$(grep -E 'workqueue_execute_start:.*f2fs_write_end_io_work' "$OUT/trace.log" | wc -l)"
    echo
    echo "Compare cyclictest Max/Avg and P99-style histogram (if enabled) across stock and patched images."
    echo "Use trace.log to correlate sched_wakeup/sched_switch, IRQ activity, block completions and F2FS workqueue callback."
} > "$OUT/summary.txt"

log "Results:"
cat "$OUT/summary.txt"
log "Raw trace: $OUT/trace.log"
exit $((FIO_RC != 0 || CYCLIC_RC != 0))
