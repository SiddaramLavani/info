# U03: 4 KiB append+fdatasync latency/IOPS while large sequential writes stream to the same UFS LUN
#      (large write bios in flight, small synchronous writes competing) + IRQ-CPU load.
TEST=U03_fsync_under_stream; . "$(dirname "$0")/lib.sh"
u_prepare
irq=$(detect_irq_cpu)
for REP in $(seq 1 "$LAT_REPEAT"); do
  rm -rf "$MNT/u03" "$MNT/ld0" "$MNT/ld1"; mkdir -p "$MNT/u03"; sync; drop_caches; sleep "$COOLDOWN"
  ( cycle_load $((LOAD_SECS + 8)) ) & lp=$!
  sleep 3
  s0=$(cpu_snap); c0=$(cpun_snap "$irq"); d0=$(dstat_snap); t0=$(now)
  run_fio fg --name=fg --directory="$MNT/u03" --rw=write --bs=4k --size=32M --numjobs=4 --time_based --runtime="$LOAD_SECS" \
      --ioengine=psync --direct=0 --fdatasync=1 --group_reporting --lat_percentiles=1 --percentile_list=50:90:99:99.9:99.99 \
      || { fail "fio failed (rep $REP)"; wait "$lp"; continue; }
  t1=$(now); s1=$(cpu_snap); c1=$(cpun_snap "$irq"); d1=$(dstat_snap)
  wait "$lp"
  el=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.3f", b-a}')
  ios=$(fio_get "$FIO_OUT" fg write.total_ios); rt=$(fio_get "$FIO_OUT" fg job_runtime)
  metric fg_ops_per_s "$(awk -v n="$ios" -v r="$rt" 'BEGIN{printf "%.1f", n*1000/r}')"
  for p in 50 90 99 99.9 99.99; do metric "fsync_p${p}_us" "$(fio_pct "$FIO_OUT" fg sync lat_ns "$(printf '%.6f' "$p")")"; done
  cpu_metrics "$s0" "$s1"; irqcpu_metrics "$c0" "$c1"; dstat_metrics "$d0" "$d1" "$el"
done
metric temp_end_c "$(thermal_max_c)"
kcheck
finish "fdatasync latency under streaming writes ($LAT_REPEAT x ${LOAD_SECS}s); n/a fsync_* = fio build without sync stats"
