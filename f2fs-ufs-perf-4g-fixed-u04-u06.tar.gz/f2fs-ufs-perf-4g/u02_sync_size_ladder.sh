# U02: per-operation latency of "write(bs) + fdatasync" for 1, 4, 16, 64 and 256 folios per bio.
#      Shows exactly where the folio limit N bites on UFS and what offloading costs per size.
TEST=U02_sync_size_ladder; . "$(dirname "$0")/lib.sh"
u_prepare
ops_for() { case $1 in 4k) echo 4000;; 16k) echo 2000;; 64k) echo 1000;; 256k) echo 500;; 1M) echo 300;; *) echo 500;; esac; }
for bs in $LADDER; do
  ops=$(ops_for "$bs"); size=$(( ops * $(bs_bytes "$bs") ))
  for REP in $(seq 1 "$LAD_REPEAT"); do
    rm -rf "$MNT/u02"; mkdir -p "$MNT/u02"; sync; drop_caches; sleep "$COOLDOWN"
    run_fio "lad_$bs" --name=lad --directory="$MNT/u02" --rw=write --bs="$bs" --size="$size" --numjobs=1 \
        --ioengine=psync --direct=0 --fdatasync=1 --lat_percentiles=1 --percentile_list=50:99:99.9 \
        || { fail "fio failed ($bs rep $REP)"; continue; }
    rt=$(fio_get "$FIO_OUT" lad job_runtime)
    metric "bs${bs}_ops_per_s" "$(awk -v n="$ops" -v r="$rt" 'BEGIN{printf "%.1f", n*1000/r}')"
    metric "bs${bs}_avg_us"    "$(awk -v n="$ops" -v r="$rt" 'BEGIN{printf "%.1f", r*1000/n}')"
    metric "bs${bs}_sync_p50_us"  "$(fio_pct "$FIO_OUT" lad sync lat_ns 50.000000)"
    metric "bs${bs}_sync_p99_us"  "$(fio_pct "$FIO_OUT" lad sync lat_ns 99.000000)"
    metric "bs${bs}_sync_p99.9_us" "$(fio_pct "$FIO_OUT" lad sync lat_ns 99.900000)"
  done
  # one extra pass with exact counters: which share of the completions was offloaded for this size?
  if [ "$(param_val)" != absent ] && have_tracefs && [ -e "$TR/function_profile_enabled" ] && have_func f2fs_write_end_io_work; then
    REP=profile; rm -rf "$MNT/u02"; mkdir -p "$MNT/u02"; sync; drop_caches
    prof_start f2fs_write_end_io f2fs_write_end_io_work
    run_fio "prof_$bs" --name=lad --directory="$MNT/u02" --rw=write --bs="$bs" --size="$size" --numjobs=1 --ioengine=psync --direct=0 --fdatasync=1
    prof_stop; tot=$(prof_hits f2fs_write_end_io); off=$(prof_hits f2fs_write_end_io_work)
    metric "bs${bs}_offload_ratio" "$(awk -v a="$off" -v b="$tot" 'BEGIN{printf "%.4f", b? a/b:0}')"; tr_reset
  fi
done
kcheck
finish "ladder ${LADDER}: ops/s, avg and fsync percentiles per size (folios per bio = bs/4k)"
