#!/usr/bin/env bash
# usage: compare_results.sh [run_dir ...]     (default: every run under ./results)
# Prints (1) functional PASS/FAIL/SKIP per test and (2) median of every perf metric per run,
# with the % change relative to the FIRST column (so list the baseline run first).
HERE="$(cd "$(dirname "$0")" && pwd)"
dirs=("$@"); [ ${#dirs[@]} -gt 0 ] || dirs=("$HERE"/results/*/)
rows=$(mktemp); trap 'rm -f "$rows"' EXIT
for d in "${dirs[@]}"; do
  d=${d%/}; [ -d "$d" ] || continue
  tag=$(cat "$d/tag" 2>/dev/null || basename "$d")
  [ -f "$d/summary.csv" ] && awk -F, -v t="$tag" '{print "S," t "," $1 "," $2}' "$d/summary.csv" >> "$rows"
  [ -f "$d/metrics.csv" ] && awk -F, -v t="$tag" '{print "M," t "," $2 "," $3 "," $5}' "$d/metrics.csv" >> "$rows"
done
echo "=== functional results ==="
awk -F, '$1=="S"{ if(!($2 in ti)){ti[$2]=++nt; tg[nt]=$2}
                  if(!($3 in si)){si[$3]=++ns; sn[ns]=$3}
                  r[$2,$3]=$4 }
  END{ printf "%-26s","test"; for(i=1;i<=nt;i++) printf " %-16s", tg[i]; print "";
       for(j=1;j<=ns;j++){ printf "%-26s", sn[j]; for(i=1;i<=nt;i++) printf " %-16s", ((tg[i],sn[j]) in r)? r[tg[i],sn[j]] : "-"; print "" } }' "$rows"
echo; echo "=== performance metrics (median over repetitions; % vs first column) ==="
awk -F, '
function med(key,   n,i,j,t,a) { n=cnt[key]; for(i=1;i<=n;i++) a[i]=v[key,i];
  for(i=2;i<=n;i++){t=a[i];j=i-1;while(j>0&&a[j]>t){a[j+1]=a[j];j--}a[j+1]=t}
  return (n%2)? a[(n+1)/2] : (a[n/2]+a[n/2+1])/2 }
$1=="M" && $5 ~ /^-?[0-9.]+$/ { if(!($2 in ti)){ti[$2]=++nt; tg[nt]=$2}
    id=$3 "|" $4; if(!(id in mi)){mi[id]=++nm; mn[nm]=id}
    k=$2 SUBSEP id; cnt[k]++; v[k,cnt[k]]=$5 }
END{ printf "%-44s","test | metric"; for(i=1;i<=nt;i++) printf " %-22s", tg[i]; print "";
     for(j=1;j<=nm;j++){ printf "%-44s", mn[j]; base="";
       for(i=1;i<=nt;i++){ k=tg[i] SUBSEP mn[j];
         if(cnt[k]>0){ m=med(k); s=sprintf("%.2f",m);
            if(base==""&&i==1) base=m; else if(base!=""&&base!=0) s=s sprintf(" (%+.1f%%)",(m-base)*100/base) }
         else s="-";
         printf " %-22s", s }
       print "" } }' "$rows"
