# UFS performance-impact tests for the f2fs write-completion backport (Linux 6.18.2) — 4 GiB filesystem

Target: a **real UFS LUN** (or a partition of one) formatted with a **4 GiB f2fs**. Loop, null_blk, zram and
device-mapper devices are refused, and the scripts insist the device sits under a UFS host (override: `ALLOW_NON_UFS=1`).

> **Status:** scripts are syntax-checked (`bash -n`); the verdict and compare tools were run on synthetic data; the
> 4 GiB sizing logic was exercised with a mocked mkfs/mount (both sector-unit conventions accepted, an ignored size
> argument rejected); the latency probe was compiled and run. They have **not** been run on a UFS device, and fio /
> f2fs-tools were not available where they were written. Do one dry run on a scratch LUN first.

## 1. What is measured, and why UFS

UFS is a direct blk-mq device: write completions run in the UFS host controller's interrupt path (hard IRQ / softirq), where
the stock kernel finishes every folio of a write bio inline. The backport can move that work to a workqueue when a bio has
more than `N = f2fs.max_write_bio_folio_cnt` folios (default `UINT_MAX` = never). The suite answers three questions:

1. **Cost of the patch with the feature off** — baseline (stock 6.18.2) vs patched/default.
2. **Benefit of the knob** — patched/default vs patched/N: IRQ-context time, wake-up latency on the UFS IRQ CPU.
3. **Cost of the knob** — throughput, `write+fdatasync` latency, CPU split for the same N.

## 2. Filesystem size: 4 GiB

| Situation | What the scripts do |
|-----------|--------------------|
| TEST_DEV is a ~4 GiB LUN or partition (4 GiB ± 2 %) | `mkfs.f2fs` on the whole device |
| TEST_DEV is larger | `blkdiscard` only the first 4 GiB, then `mkfs.f2fs dev <sectors>` limited to 4 GiB. The sector unit of that argument is **verified at runtime**: the usable size after mount must be 3–4 GiB, otherwise the script tries the other unit (logical-block size / 512 / 4096) and aborts if none fits |
| TEST_DEV < 3.92 GiB | abort |

* f2fs reports ≈ 3.5–3.7 GiB usable on a 4 GiB volume. Workloads are **bounded so no GC is needed**: one pass writes
  4 × 256 MiB = 1 GiB (≈ 28 % of usable space); continuous loads write 1 GiB cycles and delete the previous cycle (≤ 2 GiB live).
* Mount options, identical for every run: `noatime,nodiscard,background_gc=off` (keeps UFS UNMAP and GC noise out of a tiny filesystem;
  override with `MOUNT_OPTS` if you want product defaults — but use the same for all runs).
* The filesystem lives in the **first 4 GiB of the LUN**; UFS performance can depend on the LBA region, so keep the same region for all runs.

## 3. Preconditions

**Device / UFS**
- A dedicated UFS LUN or partition ≥ 4 GiB that may be erased; not the system/data partition; nothing else writing to that LUN.
  `export I_UNDERSTAND_THIS_ERASES_TEST_DEV=yes` is mandatory.
- Same UFS state for every run (the suite records what it can read from sysfs in `env.txt`): link gear/lanes, clock scaling
  (`clkscale_enable`), clock gating, auto-hibern8, runtime/system PM levels, **WriteBooster on/off**. Fix them (e.g. disable
  clock scaling, keep WB in the same state) before the A/B runs.
- Device fill state: the rest of the UFS device should be trimmed / mostly free and equally so for every run (UFS write speed depends on free capacity and SLC/WB buffer state).
- Temperature: start each configuration at a comparable temperature; the suite records `temp_start_c` / `temp_end_c` and sleeps `COOLDOWN` (5 s) between repetitions.

**Kernels** (same config and compiler for both)
- *baseline*: stock 6.18.2 → `LABEL=baseline` (U07 SKIPs by design). *patched*: 6.18.2 + the 4 backport patches → `LABEL=patched`.
- **Non-debug kernel** (no KASAN/KCSAN/lockdep/DEBUG_ATOMIC_SLEEP); `CONFIG_PREEMPT_COUNT` for `in_atomic()`.
- Tracing (U02 counters, U04, U05, U07): `FUNCTION_TRACER`, `FUNCTION_PROFILER`, `FUNCTION_GRAPH_TRACER`, `IRQSOFF_TRACER`, `PREEMPT_TRACER`; missing ones make that test SKIP.
- Changing N: f2fs as a **module** → `set_param.sh N`; built-in → boot parameter `f2fs.max_write_bio_folio_cnt=N` and one reboot per value.

**User space**: root; bash, awk, coreutils, util-linux (`blkdiscard findmnt lsblk`), `fio` ≥ 3.x, `f2fs-tools` (`mkfs.f2fs`), `dmesg` readable; `jq` or `python3`; for U06 `gcc` or `cyclictest` or a pre-built `PROBE_BIN`; ≥ 2 CPUs. `./precheck.sh` reports what is missing.

**System state**: `performance` CPU governor / fixed frequency; `irqbalance` stopped (stable UFS IRQ affinity; with MCQ set `IRQ_CPU` to the CPU whose queue you want to probe); no other load; reboot between kernels; the suite temporarily sets `vm.dirty_bytes=128 MiB`, `vm.dirty_background_bytes=32 MiB` so writeback (and therefore write completion) is continuous, and restores them on exit.

## 4. Test cases

| ID | Script | What it does | Key metrics | ≈ time |
|----|--------|--------------|-------------|--------|
| U01 | `u01_seq_write_bw.sh` | `REPEAT` (10) passes of buffered sequential write, 4 jobs × 256 MiB, 1 MiB blocks, `end_fsync`; fresh files, `sync`, `drop_caches` and `COOLDOWN` between passes | `bw_mibps`, `cpu_*_pct`, **`irqcpu_irq/softirq/busy_pct`** (load of the UFS IRQ CPU), `dev_wr_iops`, `dev_wr_avg_kib` (average UFS write request size), `temp_*` | 3 min |
| U02 | `u02_sync_size_ladder.sh` | Per-operation cost of `write(bs)+fdatasync` for bs = 4k, 16k, 64k, 256k, 1M (= 1, 4, 16, 64, 256 folios per bio), `LAD_REPEAT` (5) runs each; plus one counted pass per size | `bs*_ops_per_s`, `bs*_avg_us`, `bs*_sync_p50/p99/p99.9_us`, **`bs*_offload_ratio`** | 6 min |
| U03 | `u03_fsync_under_stream.sh` | 4 KiB append + `fdatasync` (4 jobs) for `LOAD_SECS` (30 s) while a background writer streams 1 GiB cycles to the same LUN; `LAT_REPEAT` (3) runs | `fsync_p50…p99.99_us`, `fg_ops_per_s`, `irqcpu_*`, `dev_wr_*` | 4 min |
| U04 | `u04_completion_time.sh` | function_graph (depth 1) on `f2fs_write_end_io` and `f2fs_write_end_io_work` during `TRACE_SECS` (30 s) of streaming writes: per-call duration statistics | `end_io_{calls,avg,p50,p99,p99.9,max}_us` (time in the UFS completion context), `end_io_work_*` (kworker) | 1 min |
| U05 | `u05_irq_latency.sh` | `irqsoff` and `preemptirqsoff` tracers during streaming writes: longest atomic section system-wide, and whether f2fs completion is in the worst-case trace | `*_max_us`, `*_f2fs_frames_in_max_trace` | 2 min |
| U06 | `u06_sched_latency.sh` | SCHED_FIFO probe (200 µs period) pinned to the UFS IRQ CPU; idle floor, then `LAT_REPEAT` runs with the writers on the other CPUs | `idle_*`, `load_{min,avg,p50,p99,p99.9,max}_us` | 3 min |
| U07 | `u07_offload_ratio.sh` | Function profiler: exact number of completions vs offloaded completions for one 1 GiB pass | `completions`, `offloaded`, `offload_ratio`. Default must give 0; N = 0 giving 0 → SKIP: completions are not atomic on this UFS setup, the knob has no effect | 1 min |

Folio counts per bio matter: with 4 KiB folios a 1 MiB bio has 256 folios. Offload happens when folios **> N**, so
N = 0 offloads everything, N = 8 offloads the 16/64/256-folio sizes, N = 32 the 64/256 sizes, N = 128 only 256.
Every test creates a fresh 4 GiB filesystem first (`blkdiscard` of that 4 GiB range + `mkfs.f2fs` + mount) so all runs start from the same state.

## 5. How to run

```
export TEST_DEV=/dev/sdX  I_UNDERSTAND_THIS_ERASES_TEST_DEV=yes
./precheck.sh

LABEL=baseline ./run_all.sh                    # 1) stock 6.18.2 kernel
LABEL=patched  ./run_all.sh                    # 2) patched kernel, default (feature off)
SWEEP="0 8 32 128" ./sweep.sh                  # 3) patched kernel, N sweep (f2fs as module; else one boot per N)

./compare_results.sh results/*/                # medians side by side, % vs first column
./verdict.sh results/baseline_*  results/patched_*_default_*  cost    # PASS/FAIL gates: patch cost with feature off
./verdict.sh results/patched_*_default_* results/patched_*_N32_*  knob  # PASS/FAIL gates: benefit and cost of N=32
```
Subsets: `ONLY="u01 u03"`, `SKIP_TESTS="u05"`. Results: `results/<label>_<kernel>_<N>_<time>/{summary.csv,metrics.csv,env.txt,*.json,*_graph.txt}`.

## 6. Reading the results — gates used by `verdict.sh` (edit `G_*` / `B_*` or pass them as environment variables)

| Mode | Gate (median over repetitions) | Default limit |
|------|--------------------------------|---------------|
| cost | U01 `bw_mibps` not lower | −3 % |
| cost | U01 `irqcpu_busy_pct` not higher | +10 % |
| cost | U02 every `bs*_avg_us` not higher | +5 % |
| cost | U03 `fg_ops_per_s` not lower / `fsync_p99_us` not higher | −5 % / +10 % |
| cost | U04 `end_io_p99_us`, U06 `load_max_us` not higher | +15 % / +20 % |
| knob | **benefit:** U04 `end_io_max_us` must drop; U06 `load_max_us` and `load_p99.9_us` must drop | ≥ 30 % / ≥ 20 % |
| knob | **cost:** U01 bw / U03 ops / U03 fsync p99 / U02 avg | −5 % / −8 % / +15 % / +15 % |

These thresholds are engineering suggestions, not derived from measurements: tune them to your product and to the run-to-run spread you
observe (10 passes in U01 let you see it). A *benefit* gate that FAILs means write completion is not what dominates IRQ-side latency on your platform
(check U04 `end_io_*` at the default and U05 `f2fs_frames`) — then keep N at the default. Absolute U04 values are inflated by the graph tracer; only compare runs with each other.

## 7. Limitations

* 4 GiB with 1 GiB passes means short runs (≈ 1–3 s per U01 pass): treat single passes with suspicion and use the medians.
* Only the first 4 GiB of the LUN and a fresh, un-aged filesystem are covered; no GC pressure, no near-full behaviour, no mixed read workloads.
* Buffered writes only (O_DIRECT does not use this completion path).
* Counters/latency tracing need the ftrace options listed in §3; without them U04/U05/U07 SKIP and U02 has no `offload_ratio`.
* Results depend on UFS state (gear, clock scaling, WriteBooster, temperature) — keep it identical across runs.
