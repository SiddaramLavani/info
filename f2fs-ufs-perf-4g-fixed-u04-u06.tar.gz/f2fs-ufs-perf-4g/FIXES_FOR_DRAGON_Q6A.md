# U04 / U06 fixes for Dragon Q6A tracing setup

These changes adapt the U04 and U06 tests to the tracing features observed on the target kernel.

## U04 (`u04_completion_time.sh`)
- Uses `function_graph` directly; it does not require `CONFIG_FUNCTION_PROFILER` or `function_profile_enabled`.
- Checks that `function_graph`, `set_graph_function`, and `f2fs_write_end_io` are available before running.
- Enables `funcgraph-duration` when the kernel exposes that trace option.
- Parses function-graph closing records for per-call durations.
- Treats zero captured completion records as a failed measurement instead of reporting a misleading PASS.

## U06 (`u06_sched_latency.sh`)
- Validates probe output and fails rather than recording empty metrics.
- Uses `cyclictest` when installed; otherwise compiles and uses `lat_probe.c`.
- The custom probe now fails if CPU affinity or SCHED_FIFO setup fails, rather than silently continuing as SCHED_OTHER.
- Keeps the idle and loaded measurements on the detected UFS IRQ CPU while write load runs on the other CPUs.

## Shared helper (`lib.sh`)
- `tr_reset()` now writes only tracefs controls that actually exist. This avoids noisy errors for optional files such as `function_profile_enabled` and `tracing_max_latency` on kernels that do not provide them.

## Validation and limitations
- Shell syntax checked with `bash -n`.
- `lat_probe.c` compiled with `gcc -O2 -Wall -Wextra`.
- The function-graph duration parser was checked against representative trace output.
- These scripts have not been executed on the Dragon Q6A hardware in this environment. Run U04/U06 on the board and inspect their trace/output files before treating results as performance evidence.
- U06 requires permission to set SCHED_FIFO (normally root with CAP_SYS_NICE) and at least two usable CPUs.
