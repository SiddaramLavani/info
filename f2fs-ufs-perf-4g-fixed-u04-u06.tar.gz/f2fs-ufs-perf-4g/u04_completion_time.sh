#!/usr/bin/env bash
# U04: measure per-call duration of F2FS write completion and deferred worker.
TEST=U04_completion_time; . "$(dirname "$0")/lib.sh"
u_prepare

# This test needs function_graph only; FUNCTION_PROFILER and
# function_profile_enabled are not required.
have_tracefs || skip "tracefs is not writable"
grep -qw function_graph "$TR/available_tracers" 2>/dev/null || skip "function_graph tracer is not enabled in this kernel"
[ -e "$TR/set_graph_function" ] || skip "tracefs set_graph_function control is unavailable"
have_func f2fs_write_end_io || skip "f2fs_write_end_io is not traceable (missing from available_filter_functions)"

# Parse function_graph closing records. With funcgraph-duration enabled,
# the duration appears on the closing line, e.g. '12.345 us | } /* func */'.
gdur() {
  local fn=$1 file=$2
  awk -v f="$fn" '
    index($0, "} /* " f " */") {
      if (match($0, /[0-9]+([.][0-9]+)?[[:space:]]+us/)) {
        v=substr($0, RSTART, RLENGTH); sub(/[[:space:]]+us$/, "", v); print v
      }
    }
  ' "$file"
}

# Reset only controls that exist on this kernel.
tr_reset
: > "$TR/set_graph_function" || skip "cannot clear set_graph_function"
echo f2fs_write_end_io > "$TR/set_graph_function" || skip "cannot select f2fs_write_end_io"
if have_func f2fs_write_end_io_work; then
  echo f2fs_write_end_io_work >> "$TR/set_graph_function" || skip "cannot select f2fs_write_end_io_work"
else
  log "f2fs_write_end_io_work is not traceable; worker metrics will be zero"
fi

[ -e "$TR/max_graph_depth" ] && echo 1 > "$TR/max_graph_depth" 2>/dev/null || true
[ -e "$TR/options/funcgraph-duration" ] && echo 1 > "$TR/options/funcgraph-duration" 2>/dev/null || true
[ -e "$TR/options/funcgraph-tail" ] && echo 1 > "$TR/options/funcgraph-tail" 2>/dev/null || true
[ -e "$TR/buffer_size_kb" ] && echo 65536 > "$TR/buffer_size_kb" 2>/dev/null || true

echo function_graph > "$TR/current_tracer" || skip "cannot enable function_graph"
: > "$TR/trace" || skip "cannot clear trace buffer"
echo 1 > "$TR/tracing_on" || skip "cannot start tracing"
cycle_load "$TRACE_SECS" || { echo 0 > "$TR/tracing_on"; fail "write workload failed"; finish; }
echo 0 > "$TR/tracing_on"
cp "$TR/trace" "$RUN_DIR/${TEST}_graph.txt"

read -r n avg p50 p99 p999 mx < <(gdur f2fs_write_end_io "$RUN_DIR/${TEST}_graph.txt" | stats)
endio_calls=$n
metric end_io_calls "$n"; metric end_io_avg_us "$avg"; metric end_io_p50_us "$p50"
metric end_io_p99_us "$p99"; metric end_io_p99.9_us "$p999"; metric end_io_max_us "$mx"
log "f2fs_write_end_io: calls=$n avg=${avg}us p99=${p99}us max=${mx}us"

if have_func f2fs_write_end_io_work; then
  read -r n avg p50 p99 p999 mx < <(gdur f2fs_write_end_io_work "$RUN_DIR/${TEST}_graph.txt" | stats)
else
  n=0; avg=0; p50=0; p99=0; p999=0; mx=0
fi
metric end_io_work_calls "$n"; metric end_io_work_avg_us "$avg"; metric end_io_work_p50_us "$p50"
metric end_io_work_p99_us "$p99"; metric end_io_work_p99.9_us "$p999"; metric end_io_work_max_us "$mx"
log "f2fs_write_end_io_work: calls=$n avg=${avg}us p99=${p99}us max=${mx}us"

if [ "$endio_calls" -eq 0 ]; then
  fail "function_graph captured no f2fs_write_end_io duration records; inspect ${TEST}_graph.txt"
fi
kcheck
finish "function_graph per-call durations; compare end_io_* across parameter values (worker_* counts deferred work); tracing overhead affects absolute values"
