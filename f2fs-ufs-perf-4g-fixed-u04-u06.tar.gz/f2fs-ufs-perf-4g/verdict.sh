#!/usr/bin/env bash
# usage: verdict.sh <reference_run_dir> <candidate_run_dir> [cost|knob]
#  cost: candidate = patched/default,  reference = baseline (stock 6.18.2)  -> "does the patch cost anything with the feature off?"
#  knob: candidate = patched/N,        reference = patched/default          -> "does N help, and what does it cost?"
# Compares MEDIANS of metrics.csv against gates; limits (percent) can be overridden below or via environment.
mode=${3:-cost}; ref=${1:?reference run dir}; cand=${2:?candidate run dir}
G_BW=${G_BW:-3}; G_OPS=${G_OPS:-5}; G_FSYNC=${G_FSYNC:-10}; G_LADDER=${G_LADDER:-5}; G_IRQBUSY=${G_IRQBUSY:-10}; G_SCHED=${G_SCHED:-20}; G_ENDIO=${G_ENDIO:-15}
B_END=${B_END:-30}; B_SCHED=${B_SCHED:-20}                                    # required benefit (knob mode)
if [ "$mode" = knob ]; then G_BW=${G_BW_KNOB:-5}; G_OPS=${G_OPS_KNOB:-8}; G_FSYNC=${G_FSYNC_KNOB:-15}; G_LADDER=${G_LADDER_KNOB:-15}; fi
gates="U01_seq_write_bw|bw_mibps|hi|$G_BW|throughput
U01_seq_write_bw|irqcpu_busy_pct|lo|$G_IRQBUSY|IRQ-CPU busy %
U02_sync_size_ladder|^bs[0-9a-zA-Z]+_avg_us\$|lo|$G_LADDER|avg write+fdatasync latency
U03_fsync_under_stream|fg_ops_per_s|hi|$G_OPS|fsync IOPS under streaming
U03_fsync_under_stream|fsync_p99_us|lo|$G_FSYNC|fsync p99 under streaming"
if [ "$mode" = knob ]; then
  gates="$gates
U04_completion_time|end_io_max_us|imp|$B_END|BENEFIT: max time in completion callback
U06_sched_latency|load_max_us|imp|$B_SCHED|BENEFIT: max wake-up latency on IRQ CPU
U06_sched_latency|load_p99.9_us|imp|$B_SCHED|BENEFIT: p99.9 wake-up latency on IRQ CPU"
else
  gates="$gates
U04_completion_time|end_io_p99_us|lo|$G_ENDIO|completion callback p99
U06_sched_latency|load_max_us|lo|$G_SCHED|max wake-up latency on IRQ CPU"
fi
awk -F, -v gates="$gates" -v mode="$mode" '
function med(k,  n,i,j,t,a){n=cnt[k];for(i=1;i<=n;i++)a[i]=v[k,i];for(i=2;i<=n;i++){t=a[i];j=i-1;while(j>0&&a[j]>t){a[j+1]=a[j];j--}a[j+1]=t}return (n%2)?a[(n+1)/2]:(a[n/2]+a[n/2+1])/2}
FNR==1{f++}
$5 ~ /^-?[0-9.]+$/ { k=f SUBSEP $2 "|" $3; if(!(k in seen)){seen[k]=1; keys[$2 "|" $3]=1} cnt[k]++; v[k,cnt[k]]=$5 }
END{ ng=split(gates,G,"\n"); fails=0; n=0
  for(g=1;g<=ng;g++){ split(G[g],F,"|"); t=F[1]; re=F[2]; kind=F[3]; lim=F[4]; desc=F[5]
    for(key in keys){ split(key,K,"|"); if(K[1]!=t || K[2] !~ re) continue
      k1=1 SUBSEP key; k2=2 SUBSEP key; if(cnt[k1]==0||cnt[k2]==0) continue
      b=med(k1); c=med(k2); if(b==0) continue; d=(c-b)*100/b; bad=0
      if(kind=="hi" && d < -lim) bad=1; if(kind=="lo" && d > lim) bad=1; if(kind=="imp" && d > -lim) bad=1
      rule=(kind=="hi")?sprintf(">= -%s%%",lim):(kind=="lo")?sprintf("<= +%s%%",lim):sprintf("<= -%s%% (must improve)",lim)
      printf "%-5s %-26s %-28s ref=%-10.2f cand=%-10.2f %+7.1f%%  rule %s  [%s]\n", bad?"FAIL":"PASS", K[1], K[2], b, c, d, rule, desc
      n++; if(bad) fails++ } }
  if(n==0){print "no comparable metrics found (run the same tests on both runs)"; exit 2}
  printf "\n%s mode: %d checks, %d failed\n", mode, n, fails; exit (fails?1:0) }' "$ref/metrics.csv" "$cand/metrics.csv"
