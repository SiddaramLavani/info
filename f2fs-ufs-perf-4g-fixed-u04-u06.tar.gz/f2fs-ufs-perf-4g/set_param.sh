#!/usr/bin/env bash
# usage: set_param.sh <N|default>  - reload f2fs with max_write_bio_folio_cnt=N (f2fs must be a module).
# If f2fs is built in, the parameter can only be set on the kernel command line: f2fs.max_write_bio_folio_cnt=N (then reboot).
N=${1:?usage: set_param.sh <N|default>}
P=/sys/module/f2fs/parameters/max_write_bio_folio_cnt
[ "$(id -u)" = 0 ] || { echo "run as root"; exit 1; }
if lsmod | grep -q '^f2fs'; then
  if grep -q ' f2fs ' /proc/mounts; then echo "unmount all f2fs filesystems first"; exit 1; fi
  modprobe -r f2fs || exit 1
  if [ "$N" = default ]; then modprobe f2fs || exit 1; else modprobe f2fs max_write_bio_folio_cnt="$N" || exit 1; fi
  echo "f2fs reloaded, max_write_bio_folio_cnt=$(cat $P 2>/dev/null || echo absent)"
else
  echo "f2fs is built into this kernel -> add 'f2fs.max_write_bio_folio_cnt=$N' to the kernel cmdline (omit for default) and reboot."
  echo "current value: $(cat $P 2>/dev/null || echo absent)"; exit 3
fi
