# U07: exact share of UFS write completions that were offloaded (ftrace function profiler). Explains every other result.
TEST=U07_offload_ratio; . "$(dirname "$0")/lib.sh"
u_prepare
[ "$(param_val)" != absent ] || skip "baseline kernel has no offload path"
have_tracefs && [ -e "$TR/function_profile_enabled" ] || skip "function profiler not available"
have_func f2fs_write_end_io && have_func f2fs_write_end_io_work || skip "f2fs_write_end_io{,_work} not traceable"
rm -rf "$MNT/u07"; mkdir -p "$MNT/u07"; sync; drop_caches
prof_start f2fs_write_end_io f2fs_write_end_io_work || skip "cannot start function profiler"
run_fio w --name=w --directory="$MNT/u07" --rw=write --bs=1M --size="${JOB_MB}M" --numjobs="$JOBS" --group_reporting --ioengine=psync --direct=0 --end_fsync=1 || fail "fio failed"
prof_stop; tot=$(prof_hits f2fs_write_end_io); off=$(prof_hits f2fs_write_end_io_work)
ratio=$(awk -v a="$off" -v b="$tot" 'BEGIN{printf "%.4f", b? a/b:0}')
metric completions "$tot"; metric offloaded "$off"; metric offload_ratio "$ratio"
v=$(param_val); log "N=$v completions=$tot offloaded=$off ratio=$ratio"
[ "$tot" -gt 0 ] || fail "no completions seen"
[ "$v" != "$UINT_MAX" ] || [ "$off" = 0 ] || fail "default limit but $off completions offloaded"
if [ "$v" = 0 ] && [ "$off" = 0 ]; then kcheck; [ "$FAILED" = 0 ] && skip "N=0 but nothing offloaded: completions are not in atomic context on this UFS setup - the knob has no effect here"; exit 1; fi
kcheck
finish "completions=$tot offloaded=$off ratio=$ratio (N=$v)"
