#!/usr/bin/env bash
# usage: SWEEP="default 0 8 32 64 128" ./sweep.sh   (f2fs as module). Runs run_all.sh once per value, then compares.
HERE="$(cd "$(dirname "$0")" && pwd)"
SWEEP=${SWEEP:-default 0 8 32 64 128}
dirs=()
for n in $SWEEP; do
  bash "$HERE/set_param.sh" "$n" || { echo "cannot set N=$n (built-in f2fs? run one value per boot instead)"; exit 3; }
  before=$(ls -d "$HERE"/results/*/ 2>/dev/null | sort)
  bash "$HERE/run_all.sh"
  new=$(comm -13 <(echo "$before") <(ls -d "$HERE"/results/*/ | sort)); dirs+=($new)
done
bash "$HERE/compare_results.sh" "${dirs[@]}"
