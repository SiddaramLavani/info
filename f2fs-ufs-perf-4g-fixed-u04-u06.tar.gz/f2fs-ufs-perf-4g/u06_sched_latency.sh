#!/usr/bin/env bash
# U06: measure wake-up latency on the CPU servicing UFS interrupts, idle and under UFS write load.
TEST=U06_sched_latency; . "$(dirname "$0")/lib.sh"
u_prepare

cpu=$(detect_irq_cpu)
others=$(other_cpus "$cpu")
[ -n "$others" ] || skip "need at least two online CPUs"
log "UFS IRQ CPU=$cpu, load CPUs=$others"

# Return six numeric fields: min avg p50 p99 p99.9 max (microseconds).
probe() {
  local secs=$1 out
  if [ -n "$PROBE_BIN" ]; then
    out=$("$PROBE_BIN" "$cpu" "$secs" 200 80) || return 1
    awk 'NF>=6 {print $1,$2,$3,$4,$5,$6; found=1} END{if(!found)exit 1}' <<< "$out"
  elif command -v cyclictest >/dev/null 2>&1; then
    out=$(cyclictest -q -p 80 -t 1 -a "$cpu" -i 200 -D "${secs}s") || return 1
    awk '
      /Min:/ { for(i=1;i<=NF;i++){ if($i=="Min:")mn=$(i+1); if($i=="Avg:")av=$(i+1); if($i=="Max:")mx=$(i+1) } }
      END { if(mn=="" || av=="" || mx=="") exit 1; print mn,av,"n/a","n/a","n/a",mx }
    ' <<< "$out"
  else
    need gcc
    [ -x "$RUN_DIR/lat_probe" ] || gcc -O2 -Wall -Wextra -o "$RUN_DIR/lat_probe" "$HERE/lat_probe.c" -lrt || die "cannot build lat_probe"
    out=$("$RUN_DIR/lat_probe" "$cpu" "$secs" 200 80) || return 1
    awk 'NF>=6 {print $1,$2,$3,$4,$5,$6; found=1} END{if(!found)exit 1}' <<< "$out"
  fi
}

emit() {
  local prefix=$1 min=$2 avg=$3 p50=$4 p99=$5 p999=$6 max=$7
  metric "${prefix}min_us" "$min"; metric "${prefix}avg_us" "$avg"
  metric "${prefix}p50_us" "$p50"; metric "${prefix}p99_us" "$p99"
  metric "${prefix}p99.9_us" "$p999"; metric "${prefix}max_us" "$max"
}

# Capture and validate idle measurement; do not silently record empty values.
REP=0
vals=$(probe "$TRACE_SECS") || die "latency probe failed during idle measurement; check CPU affinity, SCHED_FIFO permission and probe output"
read -r a b c d e f <<< "$vals"
[ -n "$a" ] && [ -n "$b" ] && [ -n "$f" ] || die "invalid idle probe output: $vals"
emit idle_ "$a" "$b" "$c" "$d" "$e" "$f"

for REP in $(seq 1 "$LAT_REPEAT"); do
  rm -rf "$MNT/ld0" "$MNT/ld1"
  sync; drop_caches; sleep "$COOLDOWN"
  ( cycle_load $((TRACE_SECS + 12)) "$others" ) & lp=$!
  sleep 5
  vals=$(probe "$TRACE_SECS") || { kill "$lp" 2>/dev/null || true; wait "$lp" 2>/dev/null || true; die "latency probe failed during loaded measurement (rep $REP)"; }
  read -r a b c d e f <<< "$vals"
  [ -n "$a" ] && [ -n "$b" ] && [ -n "$f" ] || { kill "$lp" 2>/dev/null || true; wait "$lp" 2>/dev/null || true; die "invalid loaded probe output: $vals"; }
  emit load_ "$a" "$b" "$c" "$d" "$e" "$f"
  wait "$lp" || fail "background UFS write workload failed in repetition $REP"
  log "rep $REP: probe max=${f}us p99.9=${e}us"
done
kcheck
finish "idle_* = scheduling-latency floor; load_* = latency on UFS IRQ CPU under UFS write load; lower max/p99.9 is better"
