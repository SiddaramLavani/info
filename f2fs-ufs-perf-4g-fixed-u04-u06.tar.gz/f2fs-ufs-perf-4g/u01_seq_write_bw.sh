# U01: sustained buffered sequential write on UFS: throughput, CPU split, IRQ-CPU load, device request size.
TEST=U01_seq_write_bw; . "$(dirname "$0")/lib.sh"
u_prepare
total_mib=$((JOBS * JOB_MB))
metric temp_start_c "$(thermal_max_c)"
irq=$(detect_irq_cpu)
for REP in $(seq 1 "$REPEAT"); do
  rm -rf "$MNT/u01"; mkdir -p "$MNT/u01"; sync; drop_caches; sleep "$COOLDOWN"
  s0=$(cpu_snap); c0=$(cpun_snap "$irq"); d0=$(dstat_snap); t0=$(now)
  run_fio seq --name=seq --directory="$MNT/u01" --rw=write --bs=1M --size="${JOB_MB}M" --numjobs="$JOBS" \
      --group_reporting --ioengine=psync --direct=0 --end_fsync=1 || { fail "fio failed (rep $REP)"; continue; }
  t1=$(now); s1=$(cpu_snap); c1=$(cpun_snap "$irq"); d1=$(dstat_snap)
  el=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.3f", b-a}')
  metric bw_mibps "$(awk -v m="$total_mib" -v e="$el" 'BEGIN{printf "%.1f", m/e}')"; metric elapsed_s "$el"
  cpu_metrics "$s0" "$s1"; irqcpu_metrics "$c0" "$c1"; dstat_metrics "$d0" "$d1" "$el"
done
metric temp_end_c "$(thermal_max_c)"
kcheck
finish "$REPEAT passes of ${total_mib} MiB on the ${FS_SIZE_GB} GiB filesystem (IRQ CPU $irq)"
