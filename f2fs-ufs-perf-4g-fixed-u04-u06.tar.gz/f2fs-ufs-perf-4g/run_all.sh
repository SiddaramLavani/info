#!/usr/bin/env bash
# usage: TEST_DEV=/dev/sdX I_UNDERSTAND_THIS_ERASES_TEST_DEV=yes LABEL=patched ./run_all.sh
#   ONLY="u01 u03"   SKIP_TESTS="u05"
# Runs all UFS performance tests once for the f2fs parameter value currently loaded (4 GiB filesystem).
TEST=run_all; . "$(dirname "$0")/lib.sh"
check_dev; init_run; dev_info
log "run dir: $RUN_DIR  (param tag: $(param_tag), FS ${FS_SIZE_GB} GiB on $(basename "$real"))"
rc=0
for t in u01_seq_write_bw u02_sync_size_ladder u03_fsync_under_stream u04_completion_time u05_irq_latency u06_sched_latency u07_offload_ratio; do
  short=${t%%_*}
  [ -n "${ONLY:-}" ] && ! echo " $ONLY " | grep -q " $short " && continue
  echo " ${SKIP_TESTS:-} " | grep -q " $short " && { log "skipping $t"; continue; }
  log "=== $t ==="; RUN_DIR=$RUN_DIR bash "$HERE/$t.sh" || rc=1
done
echo; echo "=== summary: $RUN_DIR ==="; cat "$RUN_DIR/summary.csv"
exit $rc
