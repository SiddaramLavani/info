# config.sh - tunables. Override any of these from the environment.
LABEL=${LABEL:-patched}                  # run label: baseline (stock 6.18.2) | patched
TEST_DEV=${TEST_DEV:-}                   # REAL UFS LUN (or partition), >= 4 GiB. ERASED by the tests!
MNT=${MNT:-/mnt/f2fs_ufs4g}
OUT_ROOT=${OUT_ROOT:-$HERE/results}
FS_SIZE_GB=${FS_SIZE_GB:-4}              # filesystem size under test (the task fixes this at 4 GiB)
MKFS_OPTS=${MKFS_OPTS:-}
# Mount options are identical for every run. nodiscard + background_gc=off keep UFS UNMAP and GC noise out of the
# measurement on such a small filesystem; override if you want to measure with the product defaults.
MOUNT_OPTS=${MOUNT_OPTS:-noatime,nodiscard,background_gc=off}
ALLOW_NON_UFS=${ALLOW_NON_UFS:-0}        # 1 = do not insist that TEST_DEV is a UFS LUN

# workload sizes (all bounded so a 4 GiB filesystem never needs GC)
JOBS=${JOBS:-4}
JOB_MB=${JOB_MB:-256}                    # JOBS x JOB_MB = 1 GiB per pass (25 % of the FS)
REPEAT=${REPEAT:-10}                     # U01 repetitions
LAT_REPEAT=${LAT_REPEAT:-3}              # U03 / U06 repetitions
LAD_REPEAT=${LAD_REPEAT:-5}              # U02 repetitions per write size
LOAD_SECS=${LOAD_SECS:-30}               # duration of the loaded windows (U03)
TRACE_SECS=${TRACE_SECS:-30}             # duration of the tracing / probe windows (U04-U06)
COOLDOWN=${COOLDOWN:-5}                  # seconds between repetitions (UFS thermal / SLC-cache recovery)
LADDER=${LADDER:-"4k 16k 64k 256k 1M"}   # U02 write sizes = 1, 4, 16, 64, 256 folios per bio
DIRTY_MB=${DIRTY_MB:-128}                # vm.dirty_bytes during the tests (restored afterwards)
DIRTY_BG_MB=${DIRTY_BG_MB:-32}           # vm.dirty_background_bytes
IRQ_CPU=${IRQ_CPU:-}                     # CPU servicing the UFS completion IRQ (auto-detected if empty)
PROBE_BIN=${PROBE_BIN:-}                 # optional pre-built lat_probe / cyclictest
