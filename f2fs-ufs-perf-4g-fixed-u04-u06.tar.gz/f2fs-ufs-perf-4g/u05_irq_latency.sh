# U05: longest irqs-off / preempt-off section system-wide while writing to UFS, and whether f2fs completion is in it.
TEST=U05_irq_latency; . "$(dirname "$0")/lib.sh"
u_prepare
have_tracefs || skip "tracefs not available"
ran=0
for tr in irqsoff preemptirqsoff; do
  grep -qw "$tr" "$TR/available_tracers" || { log "tracer $tr not built in"; continue; }
  tr_reset; echo "$tr" > "$TR/current_tracer"; echo 0 > "$TR/tracing_max_latency"; : > "$TR/trace"; echo 1 > "$TR/tracing_on"
  cycle_load "$TRACE_SECS" || fail "load failed"
  echo 0 > "$TR/tracing_on"; lat=$(cat "$TR/tracing_max_latency"); cp "$TR/trace" "$RUN_DIR/${TEST}_${tr}.txt"
  inv=$(grep -c 'f2fs_write_end\|folio_end_writeback\|ufshcd' "$RUN_DIR/${TEST}_${tr}.txt")
  inf=$(grep -c 'f2fs_write_end\|folio_end_writeback' "$RUN_DIR/${TEST}_${tr}.txt")
  metric "${tr}_max_us" "$lat"; metric "${tr}_f2fs_frames_in_max_trace" "$inf"; metric "${tr}_ufs_or_f2fs_frames" "$inv"
  log "$tr: max=${lat}us, f2fs completion frames in worst trace: $inf"; ran=1
done
[ "$ran" = 1 ] || skip "no latency tracer available"
kcheck
finish "f2fs_frames>0 means the worst irqs/preempt-off section contained f2fs write completion"
