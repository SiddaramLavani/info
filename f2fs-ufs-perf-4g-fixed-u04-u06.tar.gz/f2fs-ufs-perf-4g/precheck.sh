#!/usr/bin/env bash
# Non-destructive readiness check.  usage: TEST_DEV=/dev/sdX ./precheck.sh
HERE="$(cd "$(dirname "$0")" && pwd)"; . "$HERE/config.sh"
ok(){ printf '  [ ok ] %s\n' "$*"; }; no(){ printf '  [MISS] %s\n' "$*"; }
echo "tools:"; for t in bash fio mkfs.f2fs fsck.f2fs blkdiscard findmnt lsblk awk dmesg stat; do command -v $t >/dev/null && ok $t || no "$t (required)"; done
for t in jq python3 gcc cyclictest zcat; do command -v $t >/dev/null && ok $t || no "$t (optional: jq|python3 to parse fio json; gcc|cyclictest for U06)"; done
P=/sys/module/f2fs/parameters/max_write_bio_folio_cnt
echo "kernel: $(uname -r)"; [ -r $P ] && ok "patched kernel, max_write_bio_folio_cnt=$(cat $P)" || no "parameter absent -> baseline kernel (U07 will SKIP)"
T=; for d in /sys/kernel/tracing /sys/kernel/debug/tracing; do [ -d $d/events ] && T=$d && break; done
if [ -n "$T" ]; then ok "tracefs"; [ -e $T/function_profile_enabled ] && ok "function profiler (U02 counters, U07)" || no "function profiler"
  [ -e $T/set_graph_function ] && ok "function_graph (U04)" || no "function_graph (U04 SKIP)"
  grep -qw irqsoff $T/available_tracers && ok "irqsoff tracer (U05)" || no "irqsoff tracer (U05 SKIP/partial)"; else no "tracefs"; fi
[ -r /proc/config.gz ] && zcat /proc/config.gz | grep -E '^CONFIG_(PREEMPT_COUNT|KASAN|PROVE_LOCKING|SCSI_UFS_MCQ)=' | sed 's/^/  /'
echo "device:"
if [ -b "${TEST_DEV:-/nonexistent}" ]; then
  r=$(readlink -f "$TEST_DEV"); s=$(blockdev --getsize64 "$r"); echo "  $r = $((s/1048576)) MiB"
  [ $s -ge $((FS_SIZE_GB*1073741824*98/100)) ] && ok "size >= ${FS_SIZE_GB} GiB" || no "too small for a ${FS_SIZE_GB} GiB filesystem"
  [ $s -le $((FS_SIZE_GB*1073741824*102/100)) ] && ok "LUN/partition is ~${FS_SIZE_GB} GiB (whole device is used)" || ok "larger than ${FS_SIZE_GB} GiB: mkfs.f2fs will be limited to ${FS_SIZE_GB} GiB by sector count (verified at runtime)"
  pk=$(lsblk -no pkname "$r" | head -1); sp=$(readlink -f /sys/block/${pk:-$(basename $r)})
  case "$sp" in *ufs*|*UFS*) ok "UFS LUN ($sp)";; *) no "does not look like UFS: $sp (set ALLOW_NON_UFS=1 to override)";; esac
  echo "  UFS completion IRQs:"; grep -i ufs /proc/interrupts | head -8 | sed 's/^/    /'
  echo "  max thermal zone: $(cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | sort -n | tail -1 | awk 'NF{printf "%.1f C",$1/1000}')"
else no "TEST_DEV not set / not a block device"; fi
echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo n/a)  (use 'performance' for A/B runs)"
pgrep -x irqbalance >/dev/null && no "irqbalance is running (stop it: stable IRQ affinity needed)" || ok "irqbalance not running"
