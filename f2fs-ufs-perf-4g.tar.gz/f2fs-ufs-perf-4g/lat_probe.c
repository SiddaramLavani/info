/* lat_probe.c - wake-up latency probe: pinned SCHED_FIFO thread sleeping in fixed intervals.
 * usage: lat_probe <cpu> <seconds> [interval_us=200] [fifo_prio=80]
 * prints: min avg p50 p99 p99.9 max (microseconds) samples                                  */
#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static int cmp(const void *a, const void *b) { long x = *(const long *)a, y = *(const long *)b; return (x > y) - (x < y); }
int main(int argc, char **argv)
{
	int cpu = argc > 1 ? atoi(argv[1]) : 0, secs = argc > 2 ? atoi(argv[2]) : 30;
	long ival = (argc > 3 ? atol(argv[3]) : 200) * 1000L;
	int prio = argc > 4 ? atoi(argv[4]) : 80;
	cpu_set_t set; CPU_ZERO(&set); CPU_SET(cpu, &set);
	if (sched_setaffinity(0, sizeof set, &set)) perror("sched_setaffinity");
	if (prio > 0) { struct sched_param p = { .sched_priority = prio };
		if (sched_setscheduler(0, SCHED_FIFO, &p)) perror("sched_setscheduler (continuing as SCHED_OTHER)"); }
	long n = (long)secs * 1000000000L / ival + 16, cnt = 0;
	long *v = malloc(n * sizeof *v); if (!v) return 1;
	struct timespec next, now; clock_gettime(CLOCK_MONOTONIC, &next);
	while (cnt < n - 1) {
		next.tv_nsec += ival; while (next.tv_nsec >= 1000000000L) { next.tv_nsec -= 1000000000L; next.tv_sec++; }
		clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
		clock_gettime(CLOCK_MONOTONIC, &now);
		v[cnt++] = (now.tv_sec - next.tv_sec) * 1000000000L + (now.tv_nsec - next.tv_nsec);
	}
	double sum = 0; for (long i = 0; i < cnt; i++) sum += v[i];
	qsort(v, cnt, sizeof *v, cmp);
#define P(q) (v[(long)((cnt - 1) * (q))] / 1000.0)
	printf("%.1f %.1f %.1f %.1f %.1f %.1f %ld\n", v[0] / 1000.0, sum / cnt / 1000.0, P(0.5), P(0.99), P(0.999), v[cnt - 1] / 1000.0, cnt);
	return 0;
}
