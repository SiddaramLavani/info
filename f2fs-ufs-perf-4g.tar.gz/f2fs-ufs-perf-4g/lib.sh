#!/usr/bin/env bash
# lib.sh - helpers for the UFS performance suite (4 GiB f2fs on a real LUN)
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config.sh
. "$HERE/config.sh"

TEST=${TEST:-lib}; FAILED=0
PARAM=/sys/module/f2fs/parameters/max_write_bio_folio_cnt
UINT_MAX=4294967295
log()  { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*" >&2; }
die()  { log "FATAL: $*"; exit 2; }
need() { command -v "$1" >/dev/null 2>&1 || die "missing tool: $1"; }
[ "$(id -u)" = 0 ] || die "run as root"

param_val() { if [ -r "$PARAM" ]; then cat "$PARAM"; else echo absent; fi; }
param_tag() { case "$(param_val)" in absent) echo baseline;; "$UINT_MAX") echo default;; *) echo "N$(param_val)";; esac; }

# ---------------------------------------------------------------- run dir / results
init_run() {
  [ -n "${RUN_DIR:-}" ] || RUN_DIR="$OUT_ROOT/${LABEL}_$(uname -r)_$(param_tag)_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$RUN_DIR"; export RUN_DIR
  echo "$LABEL/$(param_tag)" > "$RUN_DIR/tag"
  kmark "START $TEST"
}
record() { printf '%s,%s,"%s"\n' "$1" "$2" "$3" >> "$RUN_DIR/summary.csv"; printf '%-26s %-5s %s\n' "$1" "$2" "$3"; }
fail()   { record "$TEST" FAIL "$1"; FAILED=1; }
skip()   { record "$TEST" SKIP "$1"; exit 0; }
finish() { if [ "$FAILED" = 0 ]; then record "$TEST" PASS "${1:-}"; exit 0; else exit 1; fi; }
metric() { printf '%s,%s,%s,%s,%s\n' "$(param_tag)" "$TEST" "$1" "${REP:-0}" "$2" >> "$RUN_DIR/metrics.csv"; }

KBAD='BUG:|WARNING:|Oops|KASAN|UBSAN|lockdep|possible (circular|recursive)|hung task|blocked for more than|soft lockup|rcu.*stall|Call Trace'
KBAD_F2FS='F2FS-fs \(.*\): .*(error|Stopped filesystem|nconsistent)'
kmark() { echo "f2fs-ufs4g: $1" > /dev/kmsg 2>/dev/null || true; }
klog_since() { dmesg | awk -v m="f2fs-ufs4g: START $TEST" 'index($0,m){buf="";next} {buf=buf $0 "\n"} END{printf "%s",buf}'; }
kcheck() {
  local bad; bad=$(klog_since | grep -E "$KBAD|$KBAD_F2FS" | head -5)
  if [ -n "$bad" ]; then fail "kernel log: $(echo "$bad" | head -2 | tr '\n' '|')"; return 1; fi; return 0
}

# ---------------------------------------------------------------- device checks (real UFS LUN, 4 GiB filesystem)
check_dev() {
  [ "${I_UNDERSTAND_THIS_ERASES_TEST_DEV:-}" = yes ] || die "export I_UNDERSTAND_THIS_ERASES_TEST_DEV=yes (ALL DATA on TEST_DEV is destroyed)"
  [ -n "$TEST_DEV" ] && [ -b "$TEST_DEV" ] || die "TEST_DEV must be an existing block device (real UFS LUN)"
  real=$(readlink -f "$TEST_DEV")
  case "$(basename "$real")" in loop*|nullb*|ram*|zram*|dm-*|nbd*) die "TEST_DEV must be a real LUN, not $(basename "$real")";; esac
  local d t
  for d in $(lsblk -nrpo NAME "$real"); do
    for t in $(findmnt -rno TARGET -S "$d" 2>/dev/null); do [ "$t" = "$MNT" ] || die "refusing: $d is mounted at $t"; done
  done
  DEV_BYTES=$(blockdev --getsize64 "$real"); LBS=$(blockdev --getss "$real")
  FS_BYTES=$((FS_SIZE_GB * 1024 * 1024 * 1024))
  [ "$DEV_BYTES" -ge $((FS_BYTES - FS_BYTES / 50)) ] || die "TEST_DEV is $((DEV_BYTES / 1048576)) MiB; need >= ${FS_SIZE_GB} GiB"
  PK=$(lsblk -no pkname "$real" 2>/dev/null | head -1); PK=${PK:-$(basename "$real")}
  sysp=$(readlink -f "/sys/block/$PK" 2>/dev/null)
  case "$sysp" in *ufs*|*UFS*) ;; *) [ "$ALLOW_NON_UFS" = 1 ] || die "TEST_DEV ($sysp) does not look like a UFS LUN (set ALLOW_NON_UFS=1 to override)";; esac
  export real DEV_BYTES LBS FS_BYTES PK sysp
}
thermal_max_c() { cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | sort -n | tail -1 | awk 'NF{printf "%.1f",$1/1000;f=1} END{if(!f)printf "n/a"}'; }
ufs_info() {
  local hostdir=${sysp%%/host[0-9]*} f p
  echo "ufs_sysfs_path=$sysp"
  for f in rpm_lvl spm_lvl auto_hibern8 clkscale_enable clkgate_enable wb_on enable_wb_buf_flush wb_buf_flush_en; do
    [ -r "$hostdir/$f" ] && echo "ufs.$f=$(cat "$hostdir/$f")"
  done
  find "$hostdir" -maxdepth 3 -type f \( -name gear -o -name lane -o -name hs_rate \) 2>/dev/null | while read -r p; do echo "ufs.${p#"$hostdir"/}=$(cat "$p" 2>/dev/null)"; done
  [ -r "/sys/block/$PK/device/queue_depth" ] && echo "scsi.queue_depth=$(cat "/sys/block/$PK/device/queue_depth")"
  grep -i 'ufs' /proc/interrupts 2>/dev/null | head -16
}
dev_info() {
  {
    echo "label=$LABEL"; echo "kernel=$(uname -a)"; echo "cmdline=$(cat /proc/cmdline)"
    echo "f2fs_param=$(param_val)"; echo "dev=$real dev_mib=$((DEV_BYTES / 1048576)) fs_gib=$FS_SIZE_GB logical_block=$LBS"
    echo "mount_opts=$MOUNT_OPTS"
    lsblk -o NAME,SIZE,MODEL,VENDOR,TRAN,ROTA,SCHED "$real" 2>/dev/null
    local q=/sys/block/$PK/queue f
    for f in scheduler max_sectors_kb max_hw_sectors_kb nr_requests rq_affinity nomerges write_cache; do [ -r "$q/$f" ] && echo "queue/$f=$(cat "$q/$f")"; done
    echo "cpus=$(nproc) mem_kb=$(awk '/MemTotal/{print $2}' /proc/meminfo) governor=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"
    echo "irq_cpu=$(detect_irq_cpu) temp_max_c=$(thermal_max_c)"
    ufs_info
    fio --version 2>/dev/null; mkfs.f2fs -V 2>&1 | head -2
    command -v zcat >/dev/null && [ -r /proc/config.gz ] && zcat /proc/config.gz | grep -E '^CONFIG_(PREEMPT[A-Z_]*|FUNCTION_PROFILER|FUNCTION_GRAPH_TRACER|IRQSOFF_TRACER|PREEMPT_TRACER|KASAN|PROVE_LOCKING|SCSI_UFS_MCQ|SCSI_UFSHCD)='
  } > "$RUN_DIR/env.txt" 2>&1
}

# ---------------------------------------------------------------- 4 GiB filesystem creation (self-verifying)
fs_usable_bytes() { stat -f -c '%b %S' "$MNT" | awk '{printf "%.0f", $1*$2}'; }
umount_fs() { if mountpoint -q "$MNT" 2>/dev/null; then sync; umount "$MNT" 2>/dev/null || umount -l "$MNT"; fi; }
prep_fs() {
  umount_fs
  blkdiscard -f -o 0 -l "$FS_BYTES" "$TEST_DEV" 2>/dev/null || blkdiscard -o 0 -l "$FS_BYTES" "$TEST_DEV" 2>/dev/null || log "blkdiscard skipped/unsupported"
  local units unit arg sz ok=0 min=$((3 * 1024 * 1024 * 1024))
  if [ "$DEV_BYTES" -le $((FS_BYTES + FS_BYTES / 50)) ]; then units=whole       # LUN/partition is already ~4 GiB
  else units=$(echo "$(cat "$RUN_DIR/mkfs_unit" 2>/dev/null) $LBS 512 4096" | tr ' ' '\n' | awk 'NF && !s[$0]++' | tr '\n' ' '); fi
  mkdir -p "$MNT"
  for unit in $units; do
    if [ "$unit" = whole ]; then arg=; else arg=$((FS_BYTES / unit)); fi
    # shellcheck disable=SC2086
    mkfs.f2fs -f $MKFS_OPTS "$TEST_DEV" $arg > "$RUN_DIR/${TEST}_mkfs.log" 2>&1 || continue
    mount -t f2fs -o "$MOUNT_OPTS" "$TEST_DEV" "$MNT" 2>>"$RUN_DIR/${TEST}_mkfs.log" || continue
    sz=$(fs_usable_bytes)
    if [ "$sz" -ge "$min" ] && [ "$sz" -le "$FS_BYTES" ]; then ok=1; echo "$unit" > "$RUN_DIR/mkfs_unit"; break; fi
    umount "$MNT"
  done
  [ "$ok" = 1 ] || die "could not create a ~${FS_SIZE_GB} GiB f2fs on $TEST_DEV (usable size must be 3-${FS_SIZE_GB} GiB); use a ${FS_SIZE_GB} GiB LUN/partition"
  SYSDIR=/sys/fs/f2fs/$(basename "$real"); export SYSDIR
  log "f2fs ready: raw ${FS_SIZE_GB} GiB, usable $((sz / 1048576)) MiB, mount opts: $MOUNT_OPTS"
}
drop_caches() { sync; echo 3 > /proc/sys/vm/drop_caches; }
dirty_on() {
  DS_R=$(cat /proc/sys/vm/dirty_ratio); DS_BR=$(cat /proc/sys/vm/dirty_background_ratio)
  DS_B=$(cat /proc/sys/vm/dirty_bytes); DS_BB=$(cat /proc/sys/vm/dirty_background_bytes)
  echo $((DIRTY_BG_MB * 1048576)) > /proc/sys/vm/dirty_background_bytes; echo $((DIRTY_MB * 1048576)) > /proc/sys/vm/dirty_bytes
}
dirty_off() {
  [ -n "${DS_R:-}" ] || return 0
  if [ "$DS_B" != 0 ];  then echo "$DS_B"  > /proc/sys/vm/dirty_bytes;            else echo "$DS_R"  > /proc/sys/vm/dirty_ratio; fi
  if [ "$DS_BB" != 0 ]; then echo "$DS_BB" > /proc/sys/vm/dirty_background_bytes; else echo "$DS_BR" > /proc/sys/vm/dirty_background_ratio; fi
  DS_R=
}

# ---------------------------------------------------------------- tracefs
TR=
for d in /sys/kernel/tracing /sys/kernel/debug/tracing; do [ -d "$d/events" ] && TR=$d && break; done
if [ -z "$TR" ]; then mount -t tracefs nodev /sys/kernel/tracing 2>/dev/null && TR=/sys/kernel/tracing; fi
have_tracefs() { [ -n "$TR" ] && [ -w "$TR/current_tracer" ]; }
have_func()    { grep -qE "^$1( |\$)" "$TR/available_filter_functions" 2>/dev/null; }
tr_reset() {
  have_tracefs || return 0
  echo 0 > "$TR/tracing_on" 2>/dev/null; echo nop > "$TR/current_tracer" 2>/dev/null
  : > "$TR/set_ftrace_filter" 2>/dev/null; : > "$TR/set_graph_function" 2>/dev/null
  echo 0 > "$TR/function_profile_enabled" 2>/dev/null; echo 0 > "$TR/max_graph_depth" 2>/dev/null
  echo 0 > "$TR/tracing_max_latency" 2>/dev/null; : > "$TR/trace" 2>/dev/null
}
prof_start() { have_tracefs && [ -e "$TR/function_profile_enabled" ] || return 1
  tr_reset; local f; for f in "$@"; do have_func "$f" && echo "$f" >> "$TR/set_ftrace_filter"; done
  echo 1 > "$TR/function_profile_enabled"; }
prof_stop()    { echo 0 > "$TR/function_profile_enabled"; }
prof_hits()    { cat "$TR"/trace_stat/function* 2>/dev/null | awk -v f="$1" '$1==f{h+=$2} END{print h+0}'; }
stats() { sort -n | awk '{a[NR]=$1; s+=$1} END{ if(!NR){print "0 0 0 0 0 0"; exit}
  i50=int(NR*0.50+0.5); i99=int(NR*0.99+0.5); i999=int(NR*0.999+0.5); if(i50<1)i50=1; if(i99<1)i99=1; if(i999<1)i999=1;
  printf "%d %.3f %.3f %.3f %.3f %.3f\n", NR, s/NR, a[i50], a[i99], a[i999], a[NR] }'; }

# ---------------------------------------------------------------- CPU / device accounting
cpu_snap()  { awk '/^cpu /{print $2,$3,$4,$5,$6,$7,$8,$9}' /proc/stat; }
cpun_snap() { awk -v c="cpu$1" '$1==c{print $2,$3,$4,$5,$6,$7,$8,$9}' /proc/stat; }
cpu_metrics() { # before after -> all-CPU percentages
  local out; out=$(awk -v b="$1" -v a="$2" 'BEGIN{split(b,B," ");split(a,A," ");t=0;for(i=1;i<=8;i++){d[i]=A[i]-B[i];t+=d[i]} if(t==0)t=1;
    printf "%.2f %.2f %.2f %.2f %.2f", (d[1]+d[2])*100/t, d[3]*100/t, d[6]*100/t, d[7]*100/t, d[5]*100/t}')
  # shellcheck disable=SC2086
  set -- $out; metric cpu_user_pct "$1"; metric cpu_sys_pct "$2"; metric cpu_irq_pct "$3"; metric cpu_softirq_pct "$4"; metric cpu_iowait_pct "$5"
}
irqcpu_metrics() { # before after  (snapshots of the IRQ CPU only)
  local out; out=$(awk -v b="$1" -v a="$2" 'BEGIN{split(b,B," ");split(a,A," ");t=0;for(i=1;i<=8;i++){d[i]=A[i]-B[i];t+=d[i]} if(t==0)t=1;
    printf "%.2f %.2f %.2f", d[6]*100/t, d[7]*100/t, 100-(d[4]+d[5])*100/t}')
  # shellcheck disable=SC2086
  set -- $out; metric irqcpu_irq_pct "$1"; metric irqcpu_softirq_pct "$2"; metric irqcpu_busy_pct "$3"
}
dstat_snap() { awk '{print $5,$7}' "/sys/class/block/$(basename "$real")/stat"; }   # write ios, write sectors
dstat_metrics() { # before after seconds
  local out; out=$(awk -v b="$1" -v a="$2" -v s="$3" 'BEGIN{split(b,B," ");split(a,A," ");io=A[1]-B[1];sc=A[2]-B[2];
    printf "%.1f %.0f %.1f", sc*512/1048576/s, io/s, (io? sc*512/1024/io : 0)}')
  # shellcheck disable=SC2086
  set -- $out; metric dev_wr_mibps "$1"; metric dev_wr_iops "$2"; metric dev_wr_avg_kib "$3"
}
now() { date +%s.%N; }

# ---------------------------------------------------------------- fio / loads
run_fio() { need fio; local name=$1; shift
  FIO_OUT="$RUN_DIR/${TEST}_r${REP:-0}_${name}.json"
  fio --output-format=json --output="$FIO_OUT" "$@" >/dev/null 2>"$FIO_OUT.err" || { log "fio '$name' failed: $(tail -2 "$FIO_OUT.err" | tr '\n' ' ')"; return 1; }
}
fio_get() {
  if command -v jq >/dev/null 2>&1; then jq -r --arg j "$2" ".jobs[] | select(.jobname==\$j) | .${3} // \"n/a\"" "$1" | head -1
  elif command -v python3 >/dev/null 2>&1; then python3 - "$1" "$2" "$3" <<'PY'
import json, sys
f, job, path = sys.argv[1:4]
for j in json.load(open(f))["jobs"]:
    if j["jobname"] == job:
        v = j
        try:
            for k in path.split("."): v = v[k]
        except (KeyError, TypeError): v = "n/a"
        print(v); break
PY
  else die "need jq or python3 to parse fio json"; fi
}
fio_pct() { local v
  if command -v jq >/dev/null 2>&1; then v=$(jq -r --arg j "$2" --arg p "$5" ".jobs[] | select(.jobname==\$j) | .${3}.${4}.percentile[\$p] // \"n/a\"" "$1" | head -1)
  else v=$(python3 - "$1" "$2" "$3" "$4" "$5" <<'PY'
import json, sys
f, job, sec, key, p = sys.argv[1:6]
for j in json.load(open(f))["jobs"]:
    if j["jobname"] == job:
        try: print(j[sec][key]["percentile"][p])
        except (KeyError, TypeError): print("n/a")
        break
PY
); fi
  case $v in n/a|""|null) echo n/a ;; *) awk -v x="$v" 'BEGIN{printf "%.1f", x/1000}' ;; esac
}
bs_bytes() { case $1 in *k) echo $((${1%k} * 1024));; *M) echo $((${1%M} * 1048576));; *) echo "$1";; esac; }
detect_irq_cpu() {
  if [ -n "$IRQ_CPU" ]; then echo "$IRQ_CPU"; return; fi
  local irq; irq=$(awk '/ufshcd|ufs/{sub(":","",$1); print $1; exit}' /proc/interrupts 2>/dev/null)
  if [ -n "$irq" ] && [ -r "/proc/irq/$irq/smp_affinity_list" ]; then cut -d, -f1 "/proc/irq/$irq/smp_affinity_list" | cut -d- -f1; return; fi
  echo 0
}
other_cpus() { local c n=$(nproc) out=; for c in $(seq 0 $((n - 1))); do [ "$c" != "$1" ] && out="$out$c,"; done; echo "${out%,}"; }
cycle_load() { # secs [cpus]: continuous large sequential buffered writes, 1 GiB new data per cycle, previous cycle deleted
  local end=$(( $(date +%s) + $1 )) i=0 d
  while [ "$(date +%s)" -lt "$end" ]; do
    d="$MNT/ld$((i % 2))"; rm -rf "$d"; mkdir -p "$d"
    fio --name=ld --directory="$d" --rw=write --bs=1M --size="${JOB_MB}M" --numjobs="$JOBS" --group_reporting \
        --ioengine=psync --direct=0 ${2:+--cpus_allowed="$2"} --output=/dev/null >/dev/null 2>&1 || return 1
    i=$((i + 1))
  done
  rm -rf "$MNT/ld0" "$MNT/ld1"
}
u_prepare() { check_dev; init_run; dev_info; prep_fs; dirty_on; trap 'dirty_off; tr_reset; umount_fs' EXIT; }
