# U04: how long does f2fs_write_end_io() run (time in the UFS completion context) and how long does the kworker run?
TEST=U04_completion_time; . "$(dirname "$0")/lib.sh"
u_prepare
have_tracefs && [ -e "$TR/set_graph_function" ] && have_func f2fs_write_end_io || skip "function_graph tracer / f2fs_write_end_io not available"
gdur() { awk -v f="$1" '$0 ~ ("\\| *" f "\\(\\);") || index($0, "} /* " f " */") {
    for (i=1;i<=NF;i++) if ($i=="us" && $(i-1) ~ /^[0-9.]+$/) { print $(i-1); break } }' "$2"; }
tr_reset
echo f2fs_write_end_io > "$TR/set_graph_function"
have_func f2fs_write_end_io_work && echo f2fs_write_end_io_work >> "$TR/set_graph_function"
echo 1 > "$TR/max_graph_depth"; echo 1 > "$TR/options/funcgraph-tail" 2>/dev/null; echo 65536 > "$TR/buffer_size_kb" 2>/dev/null
echo function_graph > "$TR/current_tracer" || skip "cannot enable function_graph"
: > "$TR/trace"; echo 1 > "$TR/tracing_on"
cycle_load "$TRACE_SECS" || fail "load failed"
echo 0 > "$TR/tracing_on"; cp "$TR/trace" "$RUN_DIR/${TEST}_graph.txt"
for f in f2fs_write_end_io f2fs_write_end_io_work; do
  read -r n avg p50 p99 p999 mx < <(gdur "$f" "$RUN_DIR/${TEST}_graph.txt" | stats)
  s=${f#f2fs_write_}
  metric "${s}_calls" "$n"; metric "${s}_avg_us" "$avg"; metric "${s}_p50_us" "$p50"; metric "${s}_p99_us" "$p99"
  metric "${s}_p99.9_us" "$p999"; metric "${s}_max_us" "$mx"
  log "$f: calls=$n avg=${avg}us p99=${p99}us max=${mx}us"
done
kcheck
finish "end_io_* = time in the completion callback (UFS IRQ/softirq ctx), end_io_work_* = kworker; graph-tracer overhead inflates absolute values, compare relatively"
