# U06: wake-up latency of a SCHED_FIFO probe pinned to the UFS IRQ CPU while writes run on the other CPUs.
TEST=U06_sched_latency; . "$(dirname "$0")/lib.sh"
u_prepare
cpu=$(detect_irq_cpu); others=$(other_cpus "$cpu"); [ -n "$others" ] || skip "need >= 2 CPUs"
log "UFS IRQ CPU=$cpu, load CPUs=$others"
probe() {
  if [ -n "$PROBE_BIN" ]; then "$PROBE_BIN" "$cpu" "$1" 200 80 | awk '{print $1,$2,$3,$4,$5,$6}'
  elif command -v cyclictest >/dev/null; then
    cyclictest -q -p 80 -t 1 -a "$cpu" -i 200 -D "${1}s" | awk '/Min:/{for(i=1;i<=NF;i++){if($i=="Min:")mn=$(i+1);if($i=="Avg:")av=$(i+1);if($i=="Max:")mx=$(i+1)} print mn,av,"n/a","n/a","n/a",mx}'
  else need gcc; [ -x "$RUN_DIR/lat_probe" ] || gcc -O2 -o "$RUN_DIR/lat_probe" "$HERE/lat_probe.c" -lrt || die "cannot build lat_probe"
    "$RUN_DIR/lat_probe" "$cpu" "$1" 200 80 2>/dev/null | awk '{print $1,$2,$3,$4,$5,$6}'; fi
}
emit() { metric "${1}min_us" "$2"; metric "${1}avg_us" "$3"; metric "${1}p50_us" "$4"; metric "${1}p99_us" "$5"; metric "${1}p99.9_us" "$6"; metric "${1}max_us" "$7"; }
REP=0; read -r a b c d e f < <(probe "$TRACE_SECS"); emit idle_ "$a" "$b" "$c" "$d" "$e" "$f"
for REP in $(seq 1 "$LAT_REPEAT"); do
  rm -rf "$MNT/ld0" "$MNT/ld1"; sync; drop_caches; sleep "$COOLDOWN"
  ( cycle_load $((TRACE_SECS + 12)) "$others" ) & lp=$!
  sleep 5
  read -r a b c d e f < <(probe "$TRACE_SECS"); emit load_ "$a" "$b" "$c" "$d" "$e" "$f"
  wait "$lp"; log "rep $REP: probe max=${f}us p99.9=${e}us"
done
kcheck
finish "idle_* = floor; load_* = latency on the UFS IRQ CPU under write load (lower max/p99.9 is better)"
