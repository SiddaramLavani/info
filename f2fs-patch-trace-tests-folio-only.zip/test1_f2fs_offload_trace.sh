#!/usr/bin/env bash
# Test 1: detect F2FS BIO completion workqueue activity during buffered UFS writes.
# Usage:
#   sudo TEST_DIR=/mnt/f2fs_ufs4g LABEL=patched FOLIO_N=64 ./test1_f2fs_offload_trace.sh
#
# TEST_DIR must already be mounted as F2FS on the dedicated UFS test LUN.
# This script does NOT format or discard the device. It creates and removes only its own test directory.

set -Eeuo pipefail

TR=${TR:-/sys/kernel/tracing}
TEST_DIR=${TEST_DIR:-/mnt/f2fs_ufs4g}
LABEL=${LABEL:-run}
# Read the single parameter present in this backport. On an unpatched kernel,
# the sysfs parameter may not exist; label that run as not_applicable.
if [[ -z "${FOLIO_N:-}" ]]; then
    FOLIO_N=$(cat /sys/module/f2fs/parameters/max_write_bio_folio_cnt 2>/dev/null || echo not_applicable)
fi
SIZE=${SIZE:-256M}
JOBS=${JOBS:-4}
BS=${BS:-1M}
OUT_ROOT=${OUT_ROOT:-"$PWD/trace_results"}
STAMP=$(date +%Y%m%d_%H%M%S)
OUT="$OUT_ROOT/${LABEL}_N${FOLIO_N}_$(uname -r)_$STAMP"
WORK=""
ENABLED="$OUT/enabled_events.txt"

log() { echo "[$(date +%H:%M:%S)] $*"; }
die() { echo "ERROR: $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v fio >/dev/null || die "fio is required."
[[ -d "$TEST_DIR" ]] || die "TEST_DIR does not exist: $TEST_DIR"
[[ "$(findmnt -n -o FSTYPE -T "$TEST_DIR" 2>/dev/null)" == "f2fs" ]] ||
    die "$TEST_DIR must be on a mounted F2FS filesystem."
[[ -d "$TR/events" && -w "$TR/tracing_on" ]] || die "tracefs unavailable/writable at $TR"
[[ "$(cat "$TR/tracing_on")" == "0" ]] || die "Tracing is already active. Stop the other tracing session first."

mkdir -p "$OUT_ROOT" "$OUT"
WORK=$(mktemp -d "$TEST_DIR/f2fs_trace_test1.XXXXXX")
: > "$ENABLED"

cleanup() {
    echo 0 > "$TR/tracing_on" 2>/dev/null || true
    while IFS= read -r ev; do
        [[ -n "$ev" ]] && echo 0 > "$TR/events/${ev/:/\/}/enable" 2>/dev/null || true
    done < "$ENABLED"
    [[ -n "$WORK" && -d "$WORK" ]] && rm -rf "$WORK"
}
trap cleanup EXIT INT TERM

# Workqueue events expose the callback function pointer/name. Block and IRQ events
# provide context that storage completions occurred during the fio workload.
EVENTS=(
  workqueue:workqueue_queue_work
  workqueue:workqueue_execute_start
  workqueue:workqueue_execute_end
  block:block_rq_issue
  block:block_rq_complete
  irq:irq_handler_entry
  irq:irq_handler_exit
)

: > "$OUT/event_formats.txt"
for ev in "${EVENTS[@]}"; do
    group=${ev%%:*}; name=${ev#*:}
    file="$TR/events/$group/$name/enable"
    if [[ -e "$file" ]]; then
        echo 1 > "$file"
        echo "$ev" >> "$ENABLED"
        [[ -r "$TR/events/$group/$name/format" ]] && {
            echo "===== $ev =====" >> "$OUT/event_formats.txt"
            cat "$TR/events/$group/$name/format" >> "$OUT/event_formats.txt"
        }
    else
        log "SKIP unavailable event: $ev"
    fi
done

grep -q '^workqueue:workqueue_queue_work$' "$ENABLED" ||
    die "workqueue_queue_work trace event is unavailable; cannot verify the patch's workqueue callback."

# Larger per-CPU ring buffer reduces the chance of losing events during fio.
echo 8192 > "$TR/buffer_size_kb" 2>/dev/null || true
: > "$TR/trace"
echo 1 > "$TR/tracing_on"

log "Starting buffered fio write: $JOBS jobs x $SIZE, block size $BS"
fio --name=f2fs_patch_write \
    --directory="$WORK" \
    --filename_format='fiofile.$jobnum' \
    --rw=write --bs="$BS" --size="$SIZE" \
    --numjobs="$JOBS" --ioengine=psync --direct=0 \
    --end_fsync=1 --group_reporting \
    --output-format=json --output="$OUT/fio.json" \
    > "$OUT/fio.stdout" 2> "$OUT/fio.stderr"
FIO_RC=$?

sleep 2
echo 0 > "$TR/tracing_on"
cat "$TR/trace" > "$OUT/trace.log"

# Summaries are informational; retain trace.log as the source of truth.
{
    echo "label=$LABEL"
    echo "kernel=$(uname -r)"
    echo "folio_limit=$FOLIO_N"
    echo "test_dir=$TEST_DIR"
    echo "fio_rc=$FIO_RC"
    echo "fio_workload=${JOBS}x${SIZE}, bs=$BS, buffered (direct=0), end_fsync=1"
    echo "trace_file=$OUT/trace.log"
    echo
    echo "workqueue_queue_work_total=$(grep -c 'workqueue_queue_work:' "$OUT/trace.log" || true)"
    echo "f2fs_completion_work_queued=$(grep -E 'workqueue_queue_work:.*f2fs_write_end_io_work' "$OUT/trace.log" | wc -l)"
    echo "f2fs_completion_work_started=$(grep -E 'workqueue_execute_start:.*f2fs_write_end_io_work' "$OUT/trace.log" | wc -l)"
    echo "f2fs_completion_work_finished=$(grep -E 'workqueue_execute_end:.*f2fs_write_end_io_work' "$OUT/trace.log" | wc -l)"
    echo "block_rq_complete_events=$(grep -c 'block_rq_complete:' "$OUT/trace.log" || true)"
    echo "ufs_irq_events=$(grep -Ei 'irq_handler_(entry|exit):.*(ufshcd|ufs)' "$OUT/trace.log" | wc -l)"
    echo
    echo "Interpretation:"
    echo "- Patched kernel with a finite threshold should show f2fs_write_end_io_work queue/execute events IF qualifying BIOs complete in atomic context."
    echo "- Unpatched kernel should not show this patch-specific callback."
    echo "- Zero callback events do not prove the patch is broken: the workload may not create BIOs above N, or completions may not be in atomic context."
} > "$OUT/summary.txt"

log "fio exit code: $FIO_RC"
cat "$OUT/summary.txt"
log "Results: $OUT"
exit "$FIO_RC"
